---
date: {{ .Date }}
title: "{{ replace .Name "-" " " | title }}"
subtitle: "A subtitle (optional)"
introduction: "A short paragraph of text, shown as the first paragraph of the page (optional)"
header: /some/image.jpg (optional)
---
The markdown portion of your page.
