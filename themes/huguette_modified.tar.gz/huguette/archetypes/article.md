---
title: "{{ replace .Name "-" " " | title }}"
subtitle: "A Subtitle"
introduction: "A short paragraph of text, shown as the first paragraph of the article, and on list pages."
date: {{ .Date }}
---
This is the body of your article.
